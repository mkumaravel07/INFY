import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { Router } from "@angular/router";
import { LoginService } from '../loginService/login.service';


export interface compLoc {
  Id: string;
  Order: number;
  Name: string;
}

@Component({
  selector: 'sigup',
  templateUrl: './sigup.component.html',
  styleUrls: ['./sigup.component.css']
})


export class SigupComponent implements OnInit {

  locationControl = new FormControl('', [Validators.required]);
  comploc: compLoc[];

  ngOnInit() {
    this.data.getLocations().subscribe(
      data => {
        this.comploc = data["Locations"];

      }
    )
  }

  model = {
    companyLocation: '',
    username: '',
    password: '',
    repassword: '',
    firstName: '',
    lastName: ''
  };
  hide = true;
  fnFormControl = new FormControl('', [
    Validators.required
  ]);
  lnFormControl = new FormControl('', [
    Validators.required
  ]);


  emailFormControl = new FormControl('', [
    Validators.required,
		Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
  ]);
  constructor(private router: Router, private data: LoginService) { }

  passFormControl = new FormControl('', [
    Validators.required
  ]);

  repassFormControl = new FormControl('', [
    Validators.required
  ]);
}
