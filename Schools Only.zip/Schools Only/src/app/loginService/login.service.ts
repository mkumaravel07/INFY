import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';

@Injectable(
  {
    providedIn: 'root'
  }
)
export class LoginService {
  
  
  URLCompanies ='./assets/location.json';
  URLSchools='./assets/Schools.json'

  constructor(private http: HttpClient) { }

  getLocations(): Observable<any> {
    return this.http.get(this.URLCompanies);
  }
  getSchools(): Observable<any> {
    return this.http.get(this.URLSchools);
  }

}
