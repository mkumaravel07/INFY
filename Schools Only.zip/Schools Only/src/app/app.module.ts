import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MaterialModule } from './material';
import { LoginComponent } from './login/login.component';
import { SigupComponent } from './sigup/sigup.component';
import { MenuComponent } from './menu/menu.component';
import { HomeComponent } from './home/home.component'; 
import { CookieService } from 'ngx-cookie-service';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'sigup',
    component: SigupComponent
  },
  {
    path: 'menu',
    component: MenuComponent,
    children: [
      {
        path: 'home',
        component: HomeComponent
      }
    ]
  }
  
];

@NgModule(
  {
    declarations:
    [
      AppComponent,
      LoginComponent,
      SigupComponent,
      MenuComponent,
      HomeComponent

    ],
    imports:
    [
      BrowserModule,
      HttpClientModule,
      AppRoutingModule,
      BrowserAnimationsModule,
      MaterialModule,
      FormsModule,
      ReactiveFormsModule,
      RouterModule.forRoot(routes)
    ],
    exports: [RouterModule],
    providers:[CookieService],
    bootstrap: [AppComponent]
  }
)
export class AppModule { }
