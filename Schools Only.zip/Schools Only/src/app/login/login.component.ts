import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { Router } from "@angular/router";
import { CookieService } from 'ngx-cookie-service';

@Component(
  {
    selector: 'login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
  }
)



export class LoginComponent implements OnInit {

  constructor(private router: Router, private cookieService: CookieService) { }
  ngOnInit() {
  }

  model = {
    username: '',
    password: ''
  };
  hide = true;

  emailFormControl = new FormControl('', [
    Validators.required,
		Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
  ]);

  passFormControl = new FormControl('', [
    Validators.required
  ]);
  sendReq() {
          
          this.cookieService.set('jwtToken', '123-456-789');
          this.router.navigate(['/menu/home']);
       
  }
}

