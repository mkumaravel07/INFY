import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {MatTabsModule} from '@angular/material/tabs';
import {
  MatFormFieldModule,
  MatDividerModule,
  MatToolbarModule,
  MatIconModule,
  MatMenuModule,
  MatInputModule,
  MatGridListModule,
  MatCardModule,
  MatSelectModule,
  MatButtonModule,
  MatCheckboxModule, MatSidenavModule, MatListModule, MatTableModule
} from '@angular/material';

import { FlexLayoutModule } from "@angular/flex-layout";


import { MatRadioModule } from '@angular/material';

@NgModule(
  {
    imports:
    [
      MatSelectModule,
      MatButtonModule,
      MatCheckboxModule,
      MatToolbarModule,
      MatIconModule,
      MatMenuModule,
      MatInputModule,
      MatGridListModule,
      MatCardModule,
      MatFormFieldModule,
      MatDividerModule,
      FormsModule, MatSidenavModule, MatListModule, FlexLayoutModule, MatRadioModule, MatTabsModule, MatTableModule
    ],
    exports:
    [
      MatSelectModule,
      MatButtonModule,
      MatCheckboxModule,
      MatToolbarModule,
      MatIconModule,
      MatMenuModule,
      MatInputModule,
      MatGridListModule,
      MatCardModule,
      MatFormFieldModule,
      MatDividerModule,
      FormsModule, MatSidenavModule, MatListModule, FlexLayoutModule, MatRadioModule, MatTabsModule, MatTableModule
    ],
  }
)
export class MaterialModule { }